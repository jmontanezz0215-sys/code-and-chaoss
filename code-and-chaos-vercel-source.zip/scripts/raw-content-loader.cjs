module.exports = function rawContent(source) {
  return `export default ${JSON.stringify(source)};`;
};
