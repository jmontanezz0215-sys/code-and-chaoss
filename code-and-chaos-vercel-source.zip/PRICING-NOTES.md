# Published starting rates — October 1, 2026

USD one-time website builds: Spark $795 (1–3 pages), Surge $1,495 (5–8 pages), Supernova $2,995 (10+ pages or a store). Custom work requires a quote.

Monthly care: Essential $99, Growth $249, Dominate $599. Edit allowances and scoped content are listed on the website. Final workload and pricing require a written proposal. Third-party subscriptions, advertising spend, and extra content are separate.

These rates position Code & Chaos competitively while distinguishing smaller builds from larger stores and integrations. They are business starting offers, not guarantees of profitability or market-wide averages. No automatic discount or price-match commitment has been added.

Benchmarks checked October 1, 2026:

- Onset Media advertises Florida website packages from $1,050, $1,350, and $1,650 with different scopes: https://onset.media/website-design/
- Nova Terra Digital lists a business site at $2,498 and maintenance from $298/month: https://novaterradigital.com/pricing
- Web Market Florida advertises a $1,500 build and $200/month maintenance: https://webmarketflorida.com/web-development/florida/

The assistant uses the published rates, qualifies visitor goals, offers a smaller scope when suitable, and refers final proposals or price comparisons to the team. The upgraded conversational fallback works without an AI key. Model-generated chat still requires OPENAI_API_KEY and OPENAI_MODEL; they are not configured in Sites yet.
