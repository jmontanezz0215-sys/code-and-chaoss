import article0 from '../content/insights/florida-business-website-checklist.mdx?raw';
import article1 from '../content/insights/useful-local-location-pages.mdx?raw';
import article2 from '../content/insights/before-you-redesign-your-website.mdx?raw';
import article3 from '../content/insights/chatbots-that-help-customers.mdx?raw';
function sections(raw:string):string[][] {return raw.split(/^## /m).slice(1).map(s=>{const index=s.indexOf('\n');return[s.slice(0,index).trim(),s.slice(index).trim()];});}
const source=[article0,article1,article2,article3];
export const articles=[
  {
    "slug": "florida-business-website-checklist",
    "title": "A practical website checklist for Florida businesses",
    "category": "Web design",
    "read": "5 min read",
    "excerpt": "The decisions worth making before you invest in a new business website."
  },
  {
    "slug": "useful-local-location-pages",
    "title": "What makes a local service page useful?",
    "category": "Local SEO",
    "read": "4 min read",
    "excerpt": "Build location content around real customer questions and accurate coverage."
  },
  {
    "slug": "before-you-redesign-your-website",
    "title": "Before you redesign: know what to keep",
    "category": "Development",
    "read": "4 min read",
    "excerpt": "Protect useful content and customer journeys while planning a better website."
  },
  {
    "slug": "chatbots-that-help-customers",
    "title": "A chatbot should help, not get in the way",
    "category": "Automation",
    "read": "4 min read",
    "excerpt": "Give your assistant a focused role, approved answers, and a clear human handoff."
  }
].map((a,i)=>({...a,sections:sections(source[i])}));
