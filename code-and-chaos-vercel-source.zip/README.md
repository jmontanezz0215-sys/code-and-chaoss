# Code & Chaos

Complete responsive Florida agency website for Sites, using the Next.js App Router-compatible Vinext starter and Cloudflare Workers. Your supplied logo and MP4 are in `public/`.

## Edit content

- `data/site.config.ts`: phone, approved business email, origin, colors, social links.
- `data/services.ts`: ten services, scope, and copy.
- `data/locations.ts`: twenty locations and localized copy; add a row for another city.
- `data/packages.ts`: packages, care plans, and add-ons. Published USD starting rates are $795, $1,495, and $2,995 for builds, and $99, $249, and $599/month for care. Custom work requires a proposal.
- `data/portfolio.ts`: seven clearly labeled concepts. Replace with authorized client case studies.
- `data/testimonials.ts`: add approved customer feedback only. No ratings or client statistics are fabricated.
- `data/faq.ts` and `data/chatbot-knowledge.ts`: approved FAQ and assistant information.
- `content/insights/*.mdx`: editable Markdown/MDX-source articles. This implementation supports headings and paragraphs; the content renderer deliberately does not execute embedded JSX.
- `app/globals.css` and `app/details.css`: shared theme and responsive styles.

## Run and build

With Node 22.13 or newer and npm: `npm install`, then `npm run dev`. Production build: `npm run build`. The default build targets Sites/Cloudflare. For GitHub and Vercel deployment, use the native Next.js build described in VERCEL-DEPLOYMENT.md. Keep `.openai/hosting.json` and its project identity. Do not register a replacement site for edits.

## Forms and owner inbox

Contact, audit, and chat follow-up forms validate input server-side and persist requests in the platform D1 database (`DB`). Failed saves show an error and preserve input. A honeypot, minimum completion time, request size limits, and email-based submission limit reduce spam. Owner email notifications are prepared for jmontanezz0215@icloud.com. Configure the Resend key and verified sender as described in EMAIL-SETUP.md to activate delivery; without configuration, forms save inquiries only.

Set `ADMIN_EMAIL` in Sites runtime settings to the site owner's ChatGPT sign-in email, deploy again, then visit `/inbox`. It requires a matching signed-in identity, uses server-side authorization, and displays the latest 100 inquiries. A missing or mismatched email denies access. Do not use a business email here unless it is also the authorized ChatGPT sign-in email.

Schema lives in `db/schema.ts`. Generate additive migrations with `npm run db:generate`; deployment applies them. Never rewrite an applied migration. Local preview needs the generated migrations applied to the local D1 binding before testing successful submissions.

## Assistant and integrations

The FAQ assistant works immediately without an API key. To enable live AI, use the OpenAI Developers plugin to obtain/configure a key with approval, then set `OPENAI_API_KEY` as a Sites secret and `OPENAI_MODEL` to a supported model. The key is used only on the server. Requests are limited, questions are not stored by the API (`store: false`), and a timeout/error falls back to approved FAQ answers. Verify live AI after configuring credentials. Never paste a key into source or the chat widget.

`.env.example` documents local values. Hosted values belong in Sites runtime settings. Keys are never stored in the hosting manifest. GA4 and Search Console configuration slots are provided; analytics is not enabled without configuration. No advertising trackers are enabled by default.

## Publishing and launch notes

Use the Sites workflow to build, push the exact source, package output, save a version, and publish. New Sites are private. Make the site public only when the owner asks; search engines cannot index a private site. Update the canonical origin if attaching a custom domain. Review the privacy and terms text against the business's actual practices before a public launch.

The site includes canonical page metadata, Organization/ProfessionalService, service, FAQ, and breadcrumb JSON-LD, sitemap, robots, custom favicon, and a generated social-sharing card. No fictitious street address, coordinates, reviews, or aggregate ratings are emitted. The map link identifies the service region rather than a nonexistent office. Hours, team biographies, business email, approved rates, and real customer work need owner input. Search rankings and Lighthouse scores are targets, not verified guarantees.

WebMCP: a feature-detected `prepare_quote_request` tool fills the visible form without submitting it; unsupported browsers continue normally. A supported WebMCP execution context was not available for runtime validation in this build.



