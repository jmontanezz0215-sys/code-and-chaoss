# Deploy Code & Chaos to Vercel

The original build produces a Cloudflare Worker. Uploading only its static
assets loses the server that resolves the pages, causing non-homepage 404s.
This source now includes a native Next.js build for Vercel, including all
service, location, portfolio, and article URLs.

1. Upload the complete source to GitHub, including `vercel.json`, `app`,
   `components`, `data`, `content`, `public`, `lib`, and `scripts`.
2. Import that repository into Vercel. Set Root Directory to the folder
   containing `package.json` and `vercel.json`.
3. Use the Next.js framework preset, Node 22 or newer, build command
   `npm run build:vercel`, and output directory `.next`.
4. Redeploy the latest GitHub commit. Do not upload only `public` or
   `dist/client`, and do not rewrite every page to the homepage.
5. Open `/services`, `/portfolio`, `/pricing`, `/about`, `/contact`, and a
   portfolio detail URL directly, then refresh each page.

Local Vercel-compatible preview: `npm ci`, `npm run build:vercel`, then
`npm run start:vercel`.

## Services that need migration

Public pages and the built-in FAQ assistant work on Vercel. Sites' D1 database
and ChatGPT gateway sign-in do not transfer with a GitHub download. Inquiry
forms return an explicit storage-unavailable error until a Vercel-compatible
database adapter is configured; they never claim to save an unsaved inquiry.
The owner inbox denies access on Vercel. Configure database storage and trusted
owner authentication before relying on forms or the inbox there. Email and
AI secrets must be configured on the target host; do not commit them.

The existing `npm run build` and Sites deployment remain available.
