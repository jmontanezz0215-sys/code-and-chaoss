import {env} from 'cloudflare:workers';
export function database(){const db=(env as unknown as {DB?:D1Database}).DB;if(!db)throw Error('Lead storage is temporarily unavailable. Please call 772-666-1029.');return db;}
