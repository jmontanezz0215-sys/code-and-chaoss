// Vercel has Node environment variables, not Cloudflare service bindings.
// Database operations retain their existing unavailable-storage error until
// a database adapter is configured. Never report a successful unsaved inquiry.
export const env = process.env;
