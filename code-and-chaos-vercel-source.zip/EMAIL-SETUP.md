# Inquiry email notifications

All contact, audit, and assistant follow-up forms save inquiries to D1 first. Email notifications are addressed to **jmontanezz0215@icloud.com**. There are no SMS notifications.

To activate email, set these server-side secrets/settings in Sites or Cloudflare Workers:

- `RESEND_API_KEY`: your Resend sending API key (store as a secret).
- `NOTIFICATION_FROM_EMAIL`: a sender on a domain verified in Resend, such as `Code & Chaos <inquiries@your-domain.com>`.

The iCloud address is the recipient. It cannot be used as an arbitrary verified Resend sender. Use your own verified business domain as the sender. Replying to the notification addresses the visitor who submitted the form.

Redeploy after configuring the settings, then submit one test inquiry and verify it arrives in the iCloud inbox. API acceptance is not proof of inbox delivery. Until configured, inquiries are saved but no email is sent. A sending error does not discard the saved inquiry; delivery status is logged by inquiry ID without contact details or secrets. Automatic retries are not configured.

Documentation: https://resend.com/docs/api-reference/emails/send-email
