# Portfolio asset manifest

All seven assets were created using built-in image generation, with one independent request per asset in a parallel batch. No CLI generation was used. Each output was visually inspected. The car was generated with `transparent_background: true`; its alpha transparency was verified. The other six used `transparent_background: false`.

## automotive

Integrated path: `public/portfolio/car.webp`

Exact generation prompt:

> Use case: product-mockup. Website animation asset: an unbranded sleek silver graphite supercar coupe, entire vehicle in pure side profile facing right, both wheels clearly visible. Photoreal studio lighting and polished metal details. Wide landscape tight canvas with ample transparent margin around entire vehicle. Truly transparent background, isolated car cutout with alpha, no floor, no background, no text, no logos, no watermark.

## contractor

Integrated path: `public/portfolio/contractor.webp`

Exact generation prompt:

> Use case: photorealistic-natural. Website hero photograph of an aspirational contemporary coastal Florida house exterior with pale stone, a swimming pool and tropical planting. Architectural editorial photography, elegant realistic details, warm natural light, wide landscape framing. No people, text, logos, watermarks or UI.

## design-studio

Integrated path: `public/portfolio/studio.webp`

Exact generation prompt:

> Use case: stylized-concept. Website hero asset: sculptural polished chrome ribbon twisting within an ultramarine cobalt studio space. Artful sophisticated 3D abstraction with reflective metal and rich cobalt lighting, wide landscape composition. No text, logos, watermarks or UI.

## outdoors

Integrated path: `public/portfolio/shop.webp`

Exact generation prompt:

> Use case: product-mockup. Website hero asset: premium orange technical hiking backpack on a dark graphite studio plinth. Dramatic realistic product photography, tactile technical fabric, crisp seams and buckles, wide landscape framing. Unbranded, no text, logos, watermarks or UI.

## wellness

Integrated path: `public/portfolio/wellness.webp`

Exact generation prompt:

> Use case: photorealistic-natural. Website hero photograph: serene professional wellness studio interior with green plants, pale walls and natural sunlight. Botanical, peaceful, airy and inviting, realistic architectural editorial photography, wide landscape framing. No people, text, logos, watermarks or UI.

## advisory

Integrated path: `public/portfolio/advisory.webp`

Exact generation prompt:

> Use case: photorealistic-natural. Website hero photograph of expressive glass and steel skyscraper geometry viewed from below. Cool high-contrast architectural photography with dramatic perspective and sophisticated blue-grey light, wide landscape framing. No text, logos, watermarks or UI.

## dashboard

Integrated path: `public/portfolio/dashboard.webp`

Exact generation prompt:

> Use case: stylized-concept. Website brand hero asset: abstract glossy orange and coral translucent geometric blocks arranged as a sophisticated 3D sculpture on a dark plum background. Beautiful reflections and refractions, premium studio lighting, wide landscape framing. No text, logos, watermarks or UI.

