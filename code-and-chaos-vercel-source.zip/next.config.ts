import type { NextConfig } from "next";
import path from "node:path";

const nextConfig: NextConfig = {
  webpack(config, { webpack }) {
    // Native Next.js runs on Node; Sites continues to use vite.config.ts.
    config.plugins.push(new webpack.NormalModuleReplacementPlugin(/^cloudflare:workers$/, path.resolve("lib/vercel-env.ts")));
    config.module.rules.push({
      resourceQuery: /raw/,
      type: "javascript/auto",
      use: [path.resolve("scripts/raw-content-loader.cjs")],
    });
    return config;
  },
};

export default nextConfig;

